#ifndef STRINGCOMPARE_H
#define STRINGCOMPARE_H

int stringCompare(void* arr1, void* arr2, int index1, int index2);

#endif
