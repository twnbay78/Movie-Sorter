#ifndef FLOATCOMPARE_H
#define FLOATCOMPARE_H

int floatCompare(void* arr1, void* arr2, int index1, int index2);
#endif
