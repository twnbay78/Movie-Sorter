#ifndef INTCOMPARE_H
#define INTCOMPARE_H


void movieAssign(void* arr1, void* arr2, int index1, int index2);
int intCompare(void* arr1, void* arr2, int index1, int index2);

#endif
